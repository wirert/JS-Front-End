function lockedProfile() {
  loadProfiles();
}

async function loadProfiles() {
  const profiles = await (
    await fetch("http://localhost:3030/jsonstore/advanced/profiles")
  ).json();

  const container = document.querySelector("#main");
  container.textContent = "";

  Object.values(profiles).forEach((profile, index) =>
    container.appendChild(generateProfile(profile, index + 1))
  );
}

function generateProfile(profile, i) {
  const profileDiv = document.createElement("div");
  profileDiv.classList.add("profile");

  const img = document.createElement("img");
  img.src = "./iconProfile2.png";
  img.classList.add("userIcon");
  profileDiv.appendChild(img);

  const labelLock = document.createElement("label");
  labelLock.textContent = "Lock";
  profileDiv.appendChild(labelLock);

  const radioLock = document.createElement("input");
  radioLock.type = "radio";
  radioLock.name = `user${i}Locked`;
  radioLock.value = "lock";
  radioLock.checked = true;
  profileDiv.appendChild(radioLock);

  const labelUnlock = document.createElement("label");
  labelUnlock.textContent = "Unlock";
  profileDiv.appendChild(labelUnlock);

  const radioUnlock = document.createElement("input");
  radioUnlock.type = "radio";
  radioUnlock.name = `user${i}Locked`;
  radioUnlock.value = "unlock";
  profileDiv.appendChild(radioUnlock);

  profileDiv.appendChild(document.createElement("hr"));

  const userLabel = document.createElement("label");
  userLabel.textContent = "Username";
  profileDiv.appendChild(userLabel);

  const userNameInput = document.createElement("input");
  userNameInput.type = "text";
  userNameInput.name = `user${i}Username`;
  userNameInput.value = profile.username;
  userNameInput.disabled = true;
  userNameInput.readOnly = true;
  profileDiv.appendChild(userNameInput);

  const hiddenDiv = document.createElement("div");
  hiddenDiv.id = `user${i}HiddenFields`;
  hiddenDiv.hidden = true;
  profileDiv.appendChild(hiddenDiv);

  hiddenDiv.appendChild(document.createElement("hr"));

  const emailLabel = document.createElement("label");
  emailLabel.textContent = "Email:";
  hiddenDiv.appendChild(emailLabel);

  const emailInput = document.createElement("input");
  emailInput.type = "email";
  emailInput.name = `user${i}Email`;
  emailInput.value = profile.email;
  emailInput.disabled = true;
  emailInput.readOnly = true;
  hiddenDiv.appendChild(emailInput);

  const ageLabel = document.createElement("label");
  ageLabel.textContent = "Age:";
  hiddenDiv.appendChild(ageLabel);

  const ageInput = document.createElement("input");
  ageInput.type = "email";
  ageInput.name = `user${i}Age`;
  ageInput.value = profile.age;
  ageInput.disabled = true;
  ageInput.readOnly = true;
  hiddenDiv.appendChild(ageInput);

  const button = document.createElement("button");
  button.textContent = "Show more";
  button.addEventListener("click", lockUnlockProfile);
  profileDiv.appendChild(button);

  return profileDiv;
}

function lockUnlockProfile(e) {
  const btn = e.currentTarget;
  let radioLock = btn.parentElement.querySelector('input[value="lock"]');
  if (radioLock.checked === true) {
    return;
  }

  if (btn.innerText === "Show more") {
    btn.innerText = "Hide it";
    e.target.parentElement.querySelector(
      'div[id$="HiddenFields"'
    ).style.display = "block";
  } else {
    btn.innerText = "Show more";
    e.target.parentElement.querySelector(
      'div[id$="HiddenFields"'
    ).style.display = "none";
  }
}
